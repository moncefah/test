const change = () => {
    const color1 = document.querySelector('#colorOne');
    const color2 = document.querySelector('#colorTow');
    const contener = document.querySelector('#cont');
    const finalvalue = document.querySelector('#val');

    color1.addEventListener('input', () => {
        contener.style.backgroundImage = "linear-gradient(to right," + color1.value + ", " + color2.value + ")";
    })
    color2.addEventListener('input', () => {
            contener.style.backgroundImage = "linear-gradient(to right," + color1.value + ", " + color2.value + ")";
            finalvalue.value = " to right, " + color1.value + ", " + color2.value;
        }

    )


}
change();